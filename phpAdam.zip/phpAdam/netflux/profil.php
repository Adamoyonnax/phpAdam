<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title>Netflux</title>
        <link rel="stylesheet" href="style_netflux.css">
    </head>

    <body>

        <div class="bannière">


            <header>


                <nav>

                    <ul>
                        <li>Accueil</li>
                        <li>Séries</li>
                        <li>Films</li>
                        <li>Nouveautés les plus regardés</li>
                        <li>Ma liste</li>
                        <li>Explorer par langue</li>
                    </ul>

                </nav>



            </header>


        </div>


        <div class="video">

            <h2>Tendances actuelles</h2>

            <ul class="list">
                <button id="p">⬅️</button>
                
                <li id="pop" class="l1"><img src="BlackAdam.jpg" alt=""></li>
                <li id="pop" class="l2"><img src="SeigneurAnneaux.jpg" alt=""></li>
                <li id="pop" class="l3"><img id="pop" class="l3" src="TheRevenant.jpg" alt=""></a>
                <li id="pop" class="l4"><img src="tendance4.webp" alt=""></li>
                <li id="pop" class="l5"><img src="tendance5.webp" alt=""></li> 

                <button id="s">➡️</button>            
            </ul>






        </div>




        
    </body>
</html>
